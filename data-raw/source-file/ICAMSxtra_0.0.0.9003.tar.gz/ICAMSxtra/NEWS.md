# ICAMSxtra 0.0.0.90xx
## Added
* Functions for reading, writing, sorting and plotting exposures were added: `ReadExposure`, `WriteExposure`, `SortExposure`, `PlotExposure`, `PlotExposureToPdf`.
