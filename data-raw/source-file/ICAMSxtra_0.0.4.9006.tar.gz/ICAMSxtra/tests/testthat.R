library(testthat)
library(ICAMSxtra)

test_check("ICAMSxtra")
